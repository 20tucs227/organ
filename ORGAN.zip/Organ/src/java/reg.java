/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ADMIN
 */
public class reg extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
      
       try {
                     
            
                 String a1=request.getParameter("a1");
                 String a2=request.getParameter("a2");
                 String a3=request.getParameter("a3");
                 String a4=request.getParameter("a4");
                 String age=request.getParameter("age");
                 String dob=request.getParameter("birthdate");
                 String a5=request.getParameter("a5");
                 String a6=request.getParameter("a6");
                 String a7=request.getParameter("a7");
                 String a8=request.getParameter("a8");
                 String a9=request.getParameter("a9");
                 String a10=request.getParameter("a10");
                 String a11=request.getParameter("a11");
                 String a12=request.getParameter("a12");
                  String a13=request.getParameter("a13");
                  String a14=request.getParameter("a14");
                  String a16=request.getParameter("a16");
                  String a15="";
                  String select[] = request.getParameterValues("a15"); 
                  String str="";
                  StringBuffer sb = new StringBuffer("");
                 int j=0,flag=0;
                 HttpSession so = request.getSession(true);
                
                 String b1="",b2="",b3="",b4="";
                 Random rand=new Random();
           
            if(request.getParameter("Save")!=null)
            {
                String url = "jdbc:mysql://localhost:3306/organ";
            //Class.forName("com.mysql.jdbc.Driver");
             Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(url,"root","root");
            PreparedStatement ps;
            Statement stmt = con.createStatement();
            Statement st = con.createStatement();  
            Statement st2 = con.createStatement();  
            Statement st1 = con.createStatement();
                 
                 System.out.println(a1+age+dob+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12+a13);
                 if((a1.equals(""))||(age.equals(""))||(dob.equals(""))||(a2.equals(""))||(a3.equals(""))||(a4.equals(""))||(a5.equals(""))||(a6.equals(""))||(a7.equals(""))||(a8.equals(""))||(a9.equals(""))||(a10.equals(""))||(a11.equals(""))||(a12.equals(""))||(a13.equals(""))||(a14.equals("")))
                 {
                     request.setAttribute("ok", "1");
                     request.setAttribute("msg1", "Please Enter all the Values");
                     RequestDispatcher requestdispatcher = request.getRequestDispatcher("i1.jsp");
                     requestdispatcher.forward(request, response);
                 }
		else
                 {
                     int value;
                     value = rand.nextInt(10000);
                     System.out.println(value);
                     int vv=0;
                     ResultSet rs=st.executeQuery("select * from oregister where mobile='"+a11+"' or mail='"+a12+"' ");
                     if(rs.next())
                     {
                         b1=rs.getString(14);
                         b2=rs.getString(15);
                          
                         if(a11.equalsIgnoreCase(b1) || a12.equalsIgnoreCase(b2))
                         {
                             flag=1;
                         }
                       
                         
                     }
                    
               
                     if(flag==1)
                     {
                         System.out.println("Not insert");
                         request.setAttribute("ok", "1");
                         request.setAttribute("msg1", "Mail ID or Mobile Number Already Exists!!");
                         RequestDispatcher requestdispatcher = request.getRequestDispatcher("i1.jsp");
                         requestdispatcher.forward(request, response);
                     }

                   
                     else
                   {
                        ResultSet rs1=st.executeQuery("select max(id) from oregister ");
                     if(rs1.next())
                     {
                        vv=Integer.parseInt(rs1.getString(1))+1;
                         
                       
                         
                     }
                       System.out.println("insert");
                        j=st.executeUpdate("insert into oregister values('"+vv+"','"+a1+"','"+a2+"','"+a3+"','"+a5+"','"+dob+"','"+age+"','"+a6+"','"+a7+"','"+a8+"','"+a14+"','"+a9+"','"+a10+"','"+a11+"','"+a12+"','"+a13+"','"+a16+"')");
                        
                       request.setAttribute("ok", "1");
                       request.setAttribute("msg1", "Account Registered Successfully");
              
                    
                    RequestDispatcher requestdispatcher = request.getRequestDispatcher("i1.jsp");
                    requestdispatcher.forward(request, response);
                   }
                
                }
            }
         }
        
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally 
        {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
