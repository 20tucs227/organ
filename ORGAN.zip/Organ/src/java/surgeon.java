/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ADMIN
 */
public class surgeon extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            String url1;

            HttpSession so = request.getSession(true);
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/organ", "root", "root");
            Statement st = con.createStatement();
            Statement st1 = con.createStatement();
            Statement st2 = con.createStatement();
            Statement st3 = con.createStatement();
            Statement st4 = con.createStatement();
            Statement st5 = con.createStatement();
            Statement st6 = con.createStatement();
            int size;
            int flag=0;
            String mail="";
           
            long mob = 0;
            String b = request.getParameter("id");
            String b1 = request.getParameter("id1");
             String b2 = request.getParameter("id2");
            String a1="",a2="",a3="",a4="",a5="",a6="",a7="",a8="",a9="",a10="",a11="",a12="",a13="",a14="";
            surgeoncontract su=new surgeoncontract();
            su.setA1(a1);
            su.setA10(a10);
            su.setA11(a11);
            su.setA12(a12);
            su.setA13(a13);
            su.setA14(a14);
            su.setA2(a2);
            su.setA3(a3);
            su.setA4(a4);
            su.setA5(a5);
            su.setA6(a6);
            su.setA7(a7);
            su.setA8(a8);
            su.setA9(a9);
       int bt1=0;
            if (request.getParameter("ss1") != null) {
                String v = null;
                java.util.Date st11 = new java.util.Date();
                // Formatting date into  yyyy-MM-dd HH:mm:ss e.g 2008-10-10 11:21:10
     
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String f = formatter.format(st11);
                System.out.println("Formatted date is ==>" + f);

                System.out.println("select * from verify where vid='" + b + "' ");
                ResultSet rs = st1.executeQuery("select * from verify where vid='" + b + "' ");
                if (rs != null) {
                    if (rs.next()) {
                        a1=rs.getString(2);
                        a2=rs.getString(3);
                                 a3=rs.getString(4);
                               a4=rs.getString(5);
                               a5=rs.getString(6);
                        a6=rs.getString(7);
                                 a7=rs.getString(8);
                               a8=rs.getString(9);
                                a9=rs.getString(10);
                                 a10=rs.getString(11);
                                         }
                      ResultSet rs1 = st1.executeQuery("select * from token where tid='" + b1 + "' ");
                if (rs1 != null) {
                    if (rs1.next()) {
                        a13=rs1.getString(2);
                        a14=rs1.getString(3);
                                 
                                         }
                }
                         ResultSet rs11 = st1.executeQuery("select * from doctor where did='" + b2 + "' ");
                if (rs11 != null) {
                    if (rs11.next()) {
                        a11=rs11.getString(8);
                        a12=rs11.getString(9);
                                 
                                         }
                }
                               ResultSet r1=st3.executeQuery("select max(sid) from surgeon ");
			if(r1.next())
			{
                          
                                         bt1=Integer.parseInt(r1.getString(1))+1;
                        }     
                        System.out.println("insert into surgeon values ('"+bt1+"','"+b+"' ,'"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"','"+a6+"','"+a7+"','"+a8+"','"+a9+"','"+a10+"','"+a11+"','"+a12+"','"+b1+"','"+a13+"','"+a14+"','Accepted','"+f+"')");
                 int v1=st.executeUpdate("insert into surgeon values ('"+bt1+"','"+b+"' ,'"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"','"+a6+"','"+a7+"','"+a8+"','"+a9+"','"+a10+"','"+a11+"','"+a12+"','"+b1+"','"+a13+"','"+a14+"','Accepted','"+f+"')");
               v1=st.executeUpdate("update token set status='Accept' where tid='"+b1+"'");
                v1=st.executeUpdate("update verify set statuss='Accept' where vid='"+b+"'");
                 if(v1>=1){
                       
                         request.setAttribute("ok", "1");
                          request.setAttribute("msg", "Accepted Succesfully");
                              
                       RequestDispatcher rs2 = request.getRequestDispatcher("a6.jsp");
                rs2.forward(request, response);
                 }else{
                 
                         request.setAttribute("ok", "1");
                          request.setAttribute("msg", "Accepted failed");
                              
                       RequestDispatcher rs2 = request.getRequestDispatcher("a6.jsp");
                rs2.forward(request, response);
                 }
                     
                     
                    } else {
                         RequestDispatcher rs2 = request.getRequestDispatcher("a6.jsp");
                rs2.forward(request, response);
                    }

           

            } else{
                 RequestDispatcher rs21 = request.getRequestDispatcher("a6.jsp");
                rs21.forward(request, response);
            }



        } catch (Exception e) {
            e.printStackTrace();
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
