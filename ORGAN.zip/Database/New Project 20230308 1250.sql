-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema organ
--

CREATE DATABASE IF NOT EXISTS organ;
USE organ;

--
-- Definition of table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor` (
  `did` varchar(250) default NULL,
  `dname` varchar(500) default NULL,
  `dob` varchar(500) default NULL,
  `age` varchar(500) default NULL,
  `address` varchar(500) default NULL,
  `specialist` varchar(500) default NULL,
  `experience` varchar(500) default NULL,
  `uname` varchar(500) default NULL,
  `pass` varchar(500) default NULL,
  `role` varchar(250) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `doctor`
--

/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` (`did`,`dname`,`dob`,`age`,`address`,`specialist`,`experience`,`uname`,`pass`,`role`) VALUES 
 ('DID1001','W3GP5xiU9Uhjb796Wgk9MQ==','TBzXKsz9mPATEnFd/+wBdQ==','MjNXXEHqLx1O0TbUp9awrw==','2y3m/zU9uPE7JfyzNDPu5g==','7bM5DDRdByNDbn6PE7XG1w==','jR7Av66a/c9TE1oTOKaF8A==','DID1001','Maheshv','Doctor');
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `uname` varchar(255) default NULL,
  `pass` varchar(255) default NULL,
  `role` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`uname`,`pass`,`role`) VALUES 
 ('pharmacy','pharmacy','Admin'),
 ('phrnurse','phrnurse','Nurse'),
 ('phrlab','phrlab','Labassistance'),
 ('insurance','insurance','Insurance'),
 ('phrdoctor','phrdoctor','phrdoctor');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


--
-- Definition of table `loginblock`
--

DROP TABLE IF EXISTS `loginblock`;
CREATE TABLE `loginblock` (
  `hasblock` varchar(50) default NULL,
  `username` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  `dates` varchar(50) default NULL,
  `status` varchar(50) default NULL,
  `form` varchar(50) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `loginblock`
--

/*!40000 ALTER TABLE `loginblock` DISABLE KEYS */;
INSERT INTO `loginblock` (`hasblock`,`username`,`password`,`dates`,`status`,`form`) VALUES 
 ('870487377','asvp','asvp','2023-3-08','Valid','Organ Login'),
 ('1971668833','pharmacy','pharmacy','2023-3-08','Valid','Admin Login');
/*!40000 ALTER TABLE `loginblock` ENABLE KEYS */;


--
-- Definition of table `oregister`
--

DROP TABLE IF EXISTS `oregister`;
CREATE TABLE `oregister` (
  `id` int(11) default NULL,
  `fname` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `pass` varchar(255) default NULL,
  `bgroup` varchar(255) default NULL,
  `dob` varchar(255) default NULL,
  `age` varchar(255) default NULL,
  `gender` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `district` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `country` varchar(255) default NULL,
  `mobile` varchar(255) default NULL,
  `mail` varchar(255) default NULL,
  `role` varchar(255) default NULL,
  `organ` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `oregister`
--

/*!40000 ALTER TABLE `oregister` DISABLE KEYS */;
INSERT INTO `oregister` (`id`,`fname`,`name`,`pass`,`bgroup`,`dob`,`age`,`gender`,`address`,`city`,`district`,`state`,`country`,`mobile`,`mail`,`role`,`organ`) VALUES 
 (10000,'asvp','asvp','asvp','O+','16-05-1986','36','Male','cbe','COIMBATORE','COIMBATORE','TAMILNADU','INDIA','9791334455','ASVPERUMAL@GMAIL.COM','Organ','KIDNEY');
/*!40000 ALTER TABLE `oregister` ENABLE KEYS */;


--
-- Definition of table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE `register` (
  `uid` varchar(255) NOT NULL,
  `uname` varchar(242) NOT NULL,
  `pass` varchar(233) NOT NULL,
  `name` varchar(222) NOT NULL,
  `dob` varchar(222) NOT NULL,
  `age` varchar(222) NOT NULL,
  `address` varchar(222) NOT NULL,
  `mobile` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `role` varchar(222) NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

/*!40000 ALTER TABLE `register` DISABLE KEYS */;
INSERT INTO `register` (`uid`,`uname`,`pass`,`name`,`dob`,`age`,`address`,`mobile`,`email`,`role`) VALUES 
 ('UID10000','sathish','sathish','wmwAbkKulGnaEu9anNhp/g==','lBmgwBkM07RXiH0khLBVgA==','Tz0o5iQazfRNvhUw87Fiww==','05C2gzQJkAdzFTeshEQH8Q==','7HPSW1MntGrCSPJ07zEL+g==','Ch/KkQ79zOoSJt23FG3OupaBT5Gd6GXeWP0AEWNT6h0=','patient');
/*!40000 ALTER TABLE `register` ENABLE KEYS */;


--
-- Definition of table `surgeon`
--

DROP TABLE IF EXISTS `surgeon`;
CREATE TABLE `surgeon` (
  `sid` int(11) default NULL,
  `vid` int(11) default NULL,
  `id` int(11) default NULL,
  `fname` varchar(255) default NULL,
  `bgroup` varchar(255) default NULL,
  `dob` varchar(255) default NULL,
  `age` varchar(255) default NULL,
  `gender` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `mobile` varchar(255) default NULL,
  `mail` varchar(255) default NULL,
  `organ` varchar(255) default NULL,
  `did` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `tid` varchar(255) default NULL,
  `uid` varchar(255) default NULL,
  `uname` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `dor` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `surgeon`
--

/*!40000 ALTER TABLE `surgeon` DISABLE KEYS */;
INSERT INTO `surgeon` (`sid`,`vid`,`id`,`fname`,`bgroup`,`dob`,`age`,`gender`,`address`,`mobile`,`mail`,`organ`,`did`,`name`,`tid`,`uid`,`uname`,`status`,`dor`) VALUES 
 (10001,10000,10000,'asvp','O+','16-05-1986','36','Male','cbe','9791334455','ASVPERUMAL@GMAIL.COM','KIDNEY','DID1001','Maheshv','TKID10000','UID10000','sathish','Accepted','2023-03-08 10:18:04');
/*!40000 ALTER TABLE `surgeon` ENABLE KEYS */;


--
-- Definition of table `token`
--

DROP TABLE IF EXISTS `token`;
CREATE TABLE `token` (
  `tid` varchar(250) default NULL,
  `uid` varchar(250) default NULL,
  `uname` varchar(250) default NULL,
  `email` varchar(250) default NULL,
  `mobile` varchar(250) default NULL,
  `specialist` varchar(250) default NULL,
  `doa` varchar(250) default NULL,
  `reason` varchar(250) default NULL,
  `conform` varchar(250) default NULL,
  `dat` varchar(250) default NULL,
  `dor` varchar(250) default NULL,
  `status` varchar(250) default NULL,
  `ddate` varchar(250) default NULL,
  `bgroup` varchar(250) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `token`
--

/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` (`tid`,`uid`,`uname`,`email`,`mobile`,`specialist`,`doa`,`reason`,`conform`,`dat`,`dor`,`status`,`ddate`,`bgroup`) VALUES 
 ('TKID10000','UID10000','sathish','Ch/KkQ79zOoSJt23FG3OupaBT5Gd6GXeWP0AEWNT6h0=','7HPSW1MntGrCSPJ07zEL+g==','7bM5DDRdByNDbn6PE7XG1w==','z/73ldxu2KY5V3gOoTo09g==','w1KN9UL7ZDCi69CiBOknOQ==','Confirm','08-03-2023','2023-03-08','Accept','2023-03-08','O+');
/*!40000 ALTER TABLE `token` ENABLE KEYS */;


--
-- Definition of table `verify`
--

DROP TABLE IF EXISTS `verify`;
CREATE TABLE `verify` (
  `vid` int(11) default NULL,
  `id` int(11) default NULL,
  `fname` varchar(255) default NULL,
  `bgroup` varchar(255) default NULL,
  `dob` varchar(255) default NULL,
  `age` varchar(255) default NULL,
  `gender` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `mobile` varchar(255) default NULL,
  `mail` varchar(255) default NULL,
  `organ` varchar(255) default NULL,
  `dname` varchar(255) default NULL,
  `specialist` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `dor` varchar(255) default NULL,
  `statuss` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `verify`
--

/*!40000 ALTER TABLE `verify` DISABLE KEYS */;
INSERT INTO `verify` (`vid`,`id`,`fname`,`bgroup`,`dob`,`age`,`gender`,`address`,`mobile`,`mail`,`organ`,`dname`,`specialist`,`status`,`dor`,`statuss`) VALUES 
 (10000,10000,'asvp','O+','16-05-1986','36','Male','cbe','9791334455','ASVPERUMAL@GMAIL.COM','KIDNEY','DID1001','7bM5DDRdByNDbn6PE7XG1w==','Accept','2023-03-08 02:16:15','Accept');
/*!40000 ALTER TABLE `verify` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
